var searchData=
[
  ['calculnorme_0',['calculNorme',['../structVector2D.html#a9bf81c998c6caddea746256e9800e87b',1,'Vector2D']]],
  ['checkpokemondie_1',['checkPokemonDie',['../classBattle.html#aa6b2d02153458e53beebc111e02db744',1,'Battle']]],
  ['client_2',['Client',['../classClient.html#ae51af7aa6b8f591496a8f6a4a87a14bf',1,'Client']]],
  ['createpokemons_3',['createPokemons',['../classGame.html#aaa732edabad2363bde08a4deb23c2408',1,'Game']]]
];
