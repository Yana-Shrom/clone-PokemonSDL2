var searchData=
[
  ['player_0',['Player',['../classPlayer.html',1,'']]],
  ['pokemon_1',['Pokemon',['../classPokemon.html',1,'']]]
];
