var searchData=
[
  ['battle_0',['Battle',['../classBattle.html#abecc253b23b71da260445e4bdc8522e2',1,'Battle::Battle()'],['../classBattle.html#a19c35466fb8a290adc621233160c6bad',1,'Battle::Battle(const Player &amp;player_, const Pokemon &amp;enemyPokemon_)']]]
];
