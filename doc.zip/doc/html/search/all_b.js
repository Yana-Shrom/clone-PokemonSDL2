var searchData=
[
  ['receive_5fdata_0',['receive_data',['../classClient.html#a7647e9a8d0bc9158dad20eda3d088075',1,'Client::receive_data()'],['../classServer.html#ac4b9b8ccba974a405a5bf711f7da9821',1,'Server::receive_data()']]],
  ['right_1',['right',['../classPlayer.html#a0cf75f4fb2e42ec91a8935d62b505502',1,'Player::right()'],['../classPokemon.html#a14c6e4a92a28e7e4fe3e1dd2a21653a4',1,'Pokemon::right()']]]
];
