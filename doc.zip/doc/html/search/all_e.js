var searchData=
[
  ['up_0',['up',['../classPlayer.html#a68140fa2cd67a6e05fd214e66a22ed79',1,'Player::up()'],['../classPokemon.html#a646b044b070d78ed88da4b6a3230bcfa',1,'Pokemon::up()']]]
];
