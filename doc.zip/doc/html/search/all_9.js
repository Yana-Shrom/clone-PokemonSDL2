var searchData=
[
  ['operator_2a_0',['operator*',['../structVector2D.html#ac2aebdaa9b29874b5ce9cc961302715a',1,'Vector2D::operator*(const Vector2D &amp;a)'],['../structVector2D.html#aab29ff1935a012ebf26a5463465c1501',1,'Vector2D::operator*(const int &amp;i)']]],
  ['operator_2b_1',['operator+',['../structVector2D.html#a4f8672ab1bf5009b1872c83ccf78cdbf',1,'Vector2D']]],
  ['operator_2d_2',['operator-',['../structVector2D.html#ab60fa3aaa066ef6e23d13115098e07be',1,'Vector2D']]],
  ['operator_3d_3',['operator=',['../classSDLSprite.html#add7cf595438dacdf5348d33ca249255a',1,'SDLSprite']]]
];
