var searchData=
[
  ['character_0',['Character',['../structCharacter.html',1,'']]],
  ['client_1',['Client',['../classClient.html',1,'']]]
];
